package org.xtext.generator;

import java.io.File;
import java.io.IOException;
import com.google.inject.Guice;
import com.google.inject.Injector;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.xtext.SmaCStandaloneSetup;

public class EMFGenerator {
	
	public void exportXMI(Resource smacresource) {
		
		String absuloteTargetFolderPath = smacresource.getURI().path().toString().replace("/resource","");
		absuloteTargetFolderPath = absuloteTargetFolderPath.replace(smacresource.getURI().lastSegment().toString(), "");	
		System.out.println("AbsuloteTargetFolderPath uri: " + absuloteTargetFolderPath);
		Injector injector =  new SmaCStandaloneSetup().createInjectorAndDoEMFRegistration();
	    XtextResourceSet resourceSet = injector.getInstance(XtextResourceSet.class);
	    String inputURI =  absuloteTargetFolderPath + smacresource.getURI().lastSegment();//Sacamos el nombre con extensi�n	
	    int positionDotExtension = smacresource.getURI().lastSegment().lastIndexOf('.');
	    String nameSmacResource = smacresource.getURI().lastSegment().substring(0,positionDotExtension);//Sacamos el nombre limpio, es decir, sin extensi�n
	    String outputURI = absuloteTargetFolderPath  + nameSmacResource +".xmi";
	    System.out.println("Output uri: " + outputURI);
	    URI uri = URI.createURI(inputURI);
	    Resource xtextResource = resourceSet.getResource(uri, true);
	    EcoreUtil.resolveAll(xtextResource);
	    Resource xmiResource = resourceSet.createResource(URI.createURI(outputURI));
	    xmiResource.getContents().add(xtextResource.getContents().get(0));
	    try {
	        xmiResource.save(null);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
}
