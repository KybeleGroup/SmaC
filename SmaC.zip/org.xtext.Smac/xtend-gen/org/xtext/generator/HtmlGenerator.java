package org.xtext.generator;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.xtext.smaC.Clause;
import org.xtext.smaC.Contract;
import org.xtext.smaC.Event;
import org.xtext.smaC.File;
import org.xtext.smaC.Modifier;

@SuppressWarnings("all")
public class HtmlGenerator {
  public static CharSequence toHtml(final File root) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("\t");
    _builder.append("<html>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<head>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<style>");
    _builder.newLine();
    _builder.append("\t\t\t\t");
    _builder.append("table, th, td{ border:1px solid black;padding:5px;}\ttable border-spacing:15px; }");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("</style>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<link href=\"estilos.css\" rel=\"stylesheet\" type=\"text/css\">");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("</head>");
    _builder.newLine();
    _builder.append("\t\t");
    _builder.append("<body>");
    _builder.newLine();
    _builder.append("\t\t\t");
    _builder.append("<H1>Version: ");
    String _numberVersion = root.getVersion().getNumberVersion();
    _builder.append(_numberVersion, "\t\t\t");
    _builder.append(" ");
    String _xifexpression = null;
    String _numberVersion2 = root.getVersion().getNumberVersion2();
    boolean _tripleNotEquals = (_numberVersion2 != null);
    if (_tripleNotEquals) {
      _xifexpression = root.getVersion().getSymbol();
    }
    _builder.append(_xifexpression, "\t\t\t");
    _builder.append(" ");
    String _numberVersion2_1 = root.getVersion().getNumberVersion2();
    _builder.append(_numberVersion2_1, "\t\t\t");
    _builder.append("</H1>");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t\t");
    CharSequence _listElementsFile = HtmlGenerator.listElementsFile(root);
    _builder.append(_listElementsFile, "\t\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t\t");
    CharSequence _listContracts = HtmlGenerator.listContracts(root);
    _builder.append(_listContracts, "\t\t\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("</body>");
    _builder.newLine();
    _builder.append("</html>");
    return _builder;
  }
  
  public static CharSequence listElementsFile(final File root) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<table style=\"width:300px\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<tr>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Name Enum</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Values</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</tr>");
    _builder.newLine();
    {
      EList<org.xtext.smaC.Enum> _globalEnumerators = root.getGlobalEnumerators();
      for(final org.xtext.smaC.Enum enumerator : _globalEnumerators) {
        _builder.append("\t");
        _builder.append("<tr>");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("<td>");
        String _name = enumerator.getName();
        _builder.append(_name, "\t");
        _builder.append("</td>");
        _builder.newLineIfNotEmpty();
        {
          EList<String> _values = enumerator.getValues();
          for(final String value : _values) {
            _builder.append("\t");
            _builder.append("<td>");
            _builder.append(value, "\t");
            _builder.append("</td>");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("</tr>");
        _builder.newLine();
      }
    }
    _builder.append("</table>");
    _builder.newLine();
    _builder.append("<table style=\"width:600px\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<tr>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Name Property</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Array</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Value</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</tr>");
    _builder.newLine();
    {
      EList<EAttribute> _globalProperties = root.getGlobalProperties();
      for(final EAttribute property : _globalProperties) {
        _builder.append("\t");
        _builder.append("<tr>");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("<td>");
        String _name_1 = property.getName();
        _builder.append(_name_1, "\t");
        _builder.append("</td>");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("</tr>");
        _builder.newLine();
      }
    }
    _builder.append("</table>");
    return _builder;
  }
  
  public static CharSequence listContracts(final File root) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<table style=\"width:600px\">");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<tr>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Contract\'s name</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Contract\'s events</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Contract\'s modifiers</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("<th>Contract\'s functions</th>");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("</tr>");
    _builder.newLine();
    {
      EList<Contract> _contracts = root.getContracts();
      for(final Contract contract : _contracts) {
        _builder.append("\t");
        _builder.append("<tr>");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("<td>");
        String _name = contract.getName();
        _builder.append(_name, "\t");
        _builder.append("</td>");
        _builder.newLineIfNotEmpty();
        {
          int _size = contract.getEvents().size();
          boolean _greaterThan = (_size > 1);
          if (_greaterThan) {
            {
              EList<Event> _events = contract.getEvents();
              for(final Event event : _events) {
                _builder.append("\t");
                _builder.append("<td>");
                String _name_1 = event.getName();
                _builder.append(_name_1, "\t");
                _builder.append("</td>");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        {
          int _size_1 = contract.getModifiers().size();
          boolean _greaterThan_1 = (_size_1 > 1);
          if (_greaterThan_1) {
            {
              EList<Modifier> _modifiers = contract.getModifiers();
              for(final Modifier modifier : _modifiers) {
                _builder.append("\t");
                _builder.append("<td>");
                String _name_2 = modifier.getName();
                _builder.append(_name_2, "\t");
                _builder.append("</td>");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("\t");
        _builder.append("</tr>");
        _builder.newLine();
        {
          int _size_2 = contract.getClauses().size();
          boolean _greaterThan_2 = (_size_2 > 1);
          if (_greaterThan_2) {
            {
              EList<Clause> _clauses = contract.getClauses();
              for(final Clause clause : _clauses) {
                _builder.append("\t");
                _builder.append("<td>");
                String _name_3 = clause.getName();
                _builder.append(_name_3, "\t");
                _builder.append("</td>");
                _builder.newLineIfNotEmpty();
              }
            }
          }
        }
        _builder.append("\t");
        _builder.append("</tr>");
        _builder.newLine();
      }
    }
    _builder.append("</table>");
    return _builder;
  }
}
